[byte[]]$data = [System.IO.File]::ReadAllBytes("input.exe")
$hex = [System.BitConverter]::ToString($data).Replace('-', '')
[System.IO.File]::WriteAllText("output.txt", $hex, [System.Text.Encoding]::ASCII)