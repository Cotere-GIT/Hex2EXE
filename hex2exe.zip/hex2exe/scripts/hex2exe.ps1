﻿$hex = Get-Content -Path "input.txt" -Encoding ASCII
$bytes = [System.Convert]::FromHexString($hex)
[IO.File]::WriteAllBytes("output.exe", $bytes)