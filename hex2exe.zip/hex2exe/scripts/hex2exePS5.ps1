﻿
$hex = (Get-Content -Path "input.txt" -Encoding ASCII).Trim()


$len = $hex.Length / 2
$bytes = New-Object byte[] $len


for ($i = 0; $i -lt $hex.Length; $i += 2) {
    $pair = $hex.Substring($i, 2)
    $bytes[$i / 2] = [Convert]::ToByte($pair, 16)
}

[IO.File]::WriteAllBytes("output.exe", $bytes)