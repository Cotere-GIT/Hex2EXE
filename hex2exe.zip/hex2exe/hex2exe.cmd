cd /d %~dp0scripts
powershell.exe -ExecutionPolicy Unrestricted -File hex2exe.ps1