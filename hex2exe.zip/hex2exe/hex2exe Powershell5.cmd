cd /d %~dp0scripts
powershell.exe -ExecutionPolicy Unrestricted -File hex2exePS5.ps1