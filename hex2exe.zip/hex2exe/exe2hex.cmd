cd /d %~dp0scripts
powershell.exe -ExecutionPolicy Unrestricted -File exe2hex.ps1